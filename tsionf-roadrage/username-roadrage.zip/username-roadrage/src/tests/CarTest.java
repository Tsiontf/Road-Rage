package tests;
import org.junit.Test;
import model.*;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class CarTest {

    @Test
    public void canPass() {
        Car car = new Car(10,10, Direction.random());
        assertFalse(car.canPass(Terrain.CROSSWALK, Light.RED));
        assertFalse(car.canPass(Terrain.LIGHT, Light.RED));
        assertFalse(car.canPass(Terrain.GRASS, Light.RED));
        assertTrue(car.canPass(Terrain.STREET, Light.GREEN));
        assertFalse(car.canPass(Terrain.WALL, Light.RED));
    }

    @Test
    public void chooseDirection() {
        Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.WALL);
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.WALL);
        neighbors.put(Direction.SOUTH, Terrain.WALL);

        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;

        Car car = new Car(0, 0, Direction.random());

        for (int count = 0; count < 10; count++) {
            final Direction d = car.chooseDirection(neighbors);

            if (d == Direction.WEST) {
                seenWest = true;
            } else if (d == Direction.NORTH) {
                seenNorth = true;
            } else if (d == Direction.EAST) {
                seenEast = true;
            } else if (d == Direction.SOUTH) {
                seenSouth = true;
            }
        }

        assertTrue(!seenWest && seenNorth && !seenEast && !seenSouth);

    }

    @Test
    public void collide() {
        Car car = new Car(1,2, Direction.random());
        assertTrue(car.isAlive());
        car.collide(new Truck(0,0, Direction.random()));
        assertFalse(car.isAlive());
        car.reset();
        assertTrue(car.isAlive());
        car.collide(new Car(1,1, Direction.random()));
        assertTrue(car.isAlive());
        car.reset();
        assertTrue(car.isAlive());
        car.collide(new Human(1,1, Direction.random()));
        assertTrue(car.isAlive());
    }

    @Test
    public void getImageFileName() {
        Car car = new Car(1,2, Direction.random());
        assertTrue(car.isAlive());
        assertEquals("car.gif", car.getImageFileName());
        car.collide(new Truck(1,1, Direction.random()));
        assertFalse(car.isAlive());
        assertEquals("car_dead.gif", car.getImageFileName());
    }

    @Test
    public void getDeathTime() {
        Car car = new Car(1,1, Direction.random());
        assertEquals(15, car.getDeathTime());
    }
}