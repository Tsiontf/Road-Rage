package model;

import java.util.Map;

public class Car extends AbstractVehicle{
    public Car(int X, int Y, Direction direction) {
        super(X,Y,direction);
    }
    
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if(theTerrain == Terrain.LIGHT) {
            if(theLight == Light.RED)
                return false;
            return true;
        }
        else if(theTerrain == Terrain.CROSSWALK) {
            if(theLight == Light.RED || theLight == Light.YELLOW)
                return false;
            return true;
        }
        if(theTerrain == Terrain.STREET)
            return true;
        return false;
    }

    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        Direction direction = getDirection();
        Terrain t = theNeighbors.get(direction);
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction;
        t = theNeighbors.get(direction.left());
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction.left();
        t = theNeighbors.get(direction.right());
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction.right();
        
        return direction.reverse();
    }
    
    @Override
    public void collide(Vehicle theOther) {
        if(theOther instanceof Truck) {
            deathTime = 0;
        }
    }

    @Override
    public String getImageFileName() {
        if(isAlive())
            return "car.gif";
        return "car_dead.gif";
    }

    @Override
    public int getDeathTime() {
        // TODO Auto-generated method stub
        return 15;
    }
    
    public String toString() {
        return "Car "+super.toString();
    }
}