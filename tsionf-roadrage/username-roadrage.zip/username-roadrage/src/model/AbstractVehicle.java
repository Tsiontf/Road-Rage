package model;

import java.util.Map;
import java.util.Random;

public abstract class AbstractVehicle implements Vehicle{

    private int origX;
    private int origY;
    private int X;
    private int Y;
    private Direction direction;
    protected int deathTime;
    protected static Random random = new Random();
    
    public AbstractVehicle(int X, int Y, Direction direction) {
        this.X = X;
        this.Y = Y;
        this.direction = direction;
        this.deathTime = -1;
        origX = X;
        origY = Y;
    }
    
    @Override
    public abstract boolean canPass(Terrain theTerrain, Light theLight);

    @Override
    public abstract Direction chooseDirection(Map<Direction, Terrain> theNeighbors);

    @Override
    public abstract void collide(Vehicle theOther);

    @Override
    public abstract int getDeathTime();

    @Override
    public abstract String getImageFileName();

    @Override
    public Direction getDirection() {
        return direction;
    }

    @Override
    public int getX() {
        return X;
    }

    @Override
    public int getY() {
        return Y;
    }

    @Override
    public boolean isAlive() {
        return deathTime == -1;
    }

    @Override
    public void poke() {
        if(deathTime >= 0 && deathTime < getDeathTime())
            deathTime++;
        if(deathTime >= getDeathTime())
            reset();
    }

    @Override
    public void reset() {
        // TODO Auto-generated method stub
        this.X = origX;
        this.Y = origY;
        this.direction = direction.random();
        this.deathTime = -1;
    }

    @Override
    public void setDirection(Direction theDir) {
        this.direction = theDir;
    }

    @Override
    public void setX(int theX) {
        this.X = theX;
    }

    @Override
    public void setY(int theY) {
        this.Y = theY;
    }
    
    public String toString() {
        return "("+X+","+Y+") going "+direction;
    }
}