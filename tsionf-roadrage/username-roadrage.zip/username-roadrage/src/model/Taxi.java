package model;

import java.util.Map;

public class Taxi extends AbstractVehicle{
    private int waitTime;
    public Taxi(int X, int Y, Direction direction) {
        super(X,Y,direction);
        waitTime = 0;
    }
    
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if(theTerrain == Terrain.LIGHT) {
            if(theLight == Light.RED)
                return false;
            waitTime = 0;
            return true;
        }
        else if(theTerrain == Terrain.CROSSWALK) {
            if(theLight == Light.RED && waitTime < 3) {
                waitTime++;
                return false;
            }
            waitTime = 0;
            return true;
        }
        if(theTerrain == Terrain.STREET) {
            waitTime = 0;
            return true;
        }
        return false;        
    }

    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        Direction direction = getDirection();
        Terrain t = theNeighbors.get(direction);
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction;
        t = theNeighbors.get(direction.left());
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction.left();
        t = theNeighbors.get(direction.right());
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction.right();
        
        return direction.reverse();
    }
    
    @Override
    public void collide(Vehicle theOther) {
        if(theOther instanceof Truck) {
            deathTime = 0;
        }
    }

    @Override
    public String getImageFileName() {
        if(isAlive())
            return "taxi.gif";
        return "taxi_dead.gif";
    }

    @Override
    public int getDeathTime() {
        // TODO Auto-generated method stub
        return 15;
    }
    
    public String toString() {
        return "Taxi "+super.toString();
    }
}