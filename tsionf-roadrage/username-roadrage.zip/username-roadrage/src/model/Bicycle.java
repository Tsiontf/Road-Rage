package model;

import java.util.Map;

public class Bicycle extends AbstractVehicle{
    public Bicycle(int X, int Y, Direction direction) {
        super(X,Y,direction);
    }
    
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if(theTerrain == Terrain.CROSSWALK || theTerrain == Terrain.LIGHT) {
            if(theLight == Light.GREEN)
                return true;
            return false;
        }
        return true;
    }

    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        Direction direction = getDirection();
        Direction d = direction;
        
        if(theNeighbors.get(d) == Terrain.TRAIL)
            return d;
        d = direction.left();
        if(theNeighbors.get(d) == Terrain.TRAIL)
            return d;  
        d = direction.right();
        if(theNeighbors.get(d) == Terrain.TRAIL)
            return d; 
        
        Terrain t = theNeighbors.get(direction);
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction;
        t = theNeighbors.get(direction.left());
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction.left();
        t = theNeighbors.get(direction.right());
        if(t == Terrain.STREET || t == Terrain.CROSSWALK || t == Terrain.LIGHT)
            return direction.right();
        
        return direction.reverse();
    }
    
    @Override
    public void collide(Vehicle theOther) {
        if(theOther instanceof Truck ||
           theOther instanceof Taxi ||
           theOther instanceof Car ||
           theOther instanceof Atv) {
            deathTime = 0;
        }
    }

    @Override
    public String getImageFileName() {
        if(isAlive())
            return "bicycle.gif";
        return "bicycle_dead.gif";
    }

    @Override
    public int getDeathTime() {
        // TODO Auto-generated method stub
        return 35;
    }
    
    public String toString() {
        return "Bicycle "+super.toString();
    }
}