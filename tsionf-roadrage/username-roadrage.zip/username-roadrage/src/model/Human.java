package model;

import java.util.Map;

public class Human extends AbstractVehicle{
    public Human(int X, int Y, Direction direction) {
        super(X,Y,direction);
    }
    
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if(theTerrain == Terrain.CROSSWALK) {
            if(theLight == Light.GREEN)
                return false;
            return true;
        }else if(theTerrain == Terrain.GRASS)
            return true;
        return false;
    }

    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        Direction direction = getDirection();
        Direction d = direction;
        if(theNeighbors.get(d) == Terrain.CROSSWALK)
            return d;
        d = direction.left();
        if(theNeighbors.get(d) == Terrain.CROSSWALK)
            return d;  
        d = direction.right();
        if(theNeighbors.get(d) == Terrain.CROSSWALK)
            return d; 
        

        int start = random.nextInt(3);
        int curr = start;
        boolean found = false;
        Direction[] directions = new Direction[]{direction.left(), direction.right(),direction}; 
        
        while(!found){
            d = directions[curr];
            if(theNeighbors.get(d) == Terrain.GRASS ||
               theNeighbors.get(d) == Terrain.CROSSWALK){
                return d;
            }
            curr++;
            if(curr > 2)
                curr = 0;
            if(curr == start)
                break;
        }
        return direction.reverse();
    }
    
    @Override
    public void collide(Vehicle theOther) {
        if(!(theOther instanceof Human)) {
            deathTime = 0;
        }
    }

    @Override
    public String getImageFileName() {
        if(isAlive())
            return "human.gif";
        return "human_dead.gif";
    }

    @Override
    public int getDeathTime() {
        // TODO Auto-generated method stub
        return 45;
    }
    
    public String toString() {
        return "Human "+super.toString();
    }
}