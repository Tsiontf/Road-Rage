package model;

import java.util.Map;

public class Truck extends AbstractVehicle{

    public Truck(int X, int Y, Direction direction) {
        super(X,Y,direction);
    }
    
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if(theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT)
            return true;
        else if(theTerrain == Terrain.CROSSWALK) {
            if(theLight == Light.RED)
                return false;
            return true;
        }
        return false;
    }

    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        int start = random.nextInt(3);
        int curr = start;
        boolean found = false;
        Direction direction = getDirection();
        Direction[] directions = new Direction[]{direction.left(), direction.right(),direction}; 
        
        while(!found){
            Direction d = directions[curr];
            if(theNeighbors.get(d) == Terrain.STREET ||
               theNeighbors.get(d) == Terrain.LIGHT ||
               theNeighbors.get(d) == Terrain.CROSSWALK){
                return d;
            }
            curr++;
            if(curr > 2)
                curr = 0;
            if(curr == start)
                break;
        }
        return direction.reverse();
    }
    
    @Override
    public void collide(Vehicle theOther) {
        // TODO Auto-generated method stub
    }

    @Override
    public String getImageFileName() {
        if(isAlive())
            return "truck.gif";
        return "truck_dead.gif";
    }

    @Override
    public int getDeathTime() {
        return 0;
    }
    
    public String toString() {
        return "Truck "+super.toString();
    }
}