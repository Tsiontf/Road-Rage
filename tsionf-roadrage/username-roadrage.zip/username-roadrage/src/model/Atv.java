package model;

import java.util.Map;

public class Atv extends AbstractVehicle{
    public Atv(int X, int Y, Direction direction) {
        super(X,Y,direction);
    }
    
    @Override
    public boolean canPass(Terrain theTerrain, Light theLight) {
        if(theTerrain == Terrain.WALL)
            return false;
        return true;
    }

    @Override
    public Direction chooseDirection(Map<Direction, Terrain> theNeighbors) {
        Direction d = Direction.random();
        Terrain t = theNeighbors.get(d);
        
        while(t == Terrain.WALL) {
            d = Direction.random();
            t = theNeighbors.get(d);
        }
        
        return d;
    }
    
    @Override
    public void collide(Vehicle theOther) {
        if(theOther instanceof Truck ||
            theOther instanceof Taxi ||
            theOther instanceof Car) {
             deathTime = 0;
         }
    }

    @Override
    public String getImageFileName() {
        if(isAlive())
            return "atv.gif";
        return "atv_dead.gif";
    }

    @Override
    public int getDeathTime() {
        // TODO Auto-generated method stub
        return 25;
    }
    
    public String toString() {
        return "All Terrain Vehicle "+super.toString();
    }
}